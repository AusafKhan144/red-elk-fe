/* Red Elk — Dashboard screen */
function SectionHead({ title, sub, action }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 14, gap: 16 }}>
      <div>
        <h2 style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-.01em" }}>{title}</h2>
        {sub && <p style={{ margin: "3px 0 0", fontSize: 13, color: "var(--muted)" }}>{sub}</p>}
      </div>
      {action}
    </div>
  );
}

function MetricCard({ label, value, delta, up, icon, suffix, note }) {
  return (
    <div className="card" style={{ padding: "16px 17px", display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span className="eyebrow">{label}</span>
        <span style={{ color: "var(--faint)", display: "flex" }}><Icon name={icon} size={15} /></span>
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
        <span className="display tnum" style={{ fontSize: 34, lineHeight: 1, color: "var(--ink)" }}>{value}</span>
        {suffix && <span style={{ fontSize: 13, color: "var(--faint)" }}>{suffix}</span>}
      </div>
      {delta && (
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, fontWeight: 600,
          color: up ? "var(--t-leading)" : "var(--accent)" }}>
          <Icon name={up ? "arrowUp" : "arrowDn"} size={13} />
          <span className="tnum">{delta}</span>
          <span style={{ color: "var(--faint)", fontWeight: 500 }}>vs last quarter</span>
        </div>
      )}
      {note && (
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12.5, fontWeight: 600, color: "var(--t-leading)" }}>
          <Icon name="check" size={13} /><span>{note}</span>
        </div>
      )}
    </div>
  );
}

/* horizontal dimension bar with the 4 tier bands behind it */
function DimensionRow({ d, delay }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(d.score);
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(d.score), 80 + delay); return () => clearTimeout(t); }, []);
  const up = d.score - d.prev;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "168px 1fr 96px", alignItems: "center", gap: 16, padding: "11px 0" }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{d.label}</div>
        <div style={{ fontSize: 11.5, color: "var(--faint)", marginTop: 1 }}>{tier.label}</div>
      </div>
      <div style={{ position: "relative", height: 10, borderRadius: 999, background: "var(--surface-inset)", overflow: "hidden",
        boxShadow: "var(--inner-line)" }}>
        {/* tier band ticks */}
        {[30, 55, 75].map((p) => (
          <span key={p} style={{ position: "absolute", left: p + "%", top: 0, bottom: 0, width: 1, background: "var(--border-strong)", opacity: .7 }} />
        ))}
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: w + "%", borderRadius: 999,
          background: tier.color, transition: "width 1s var(--ease)" }} />
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 8 }}>
        <span className="mono tnum" style={{ fontSize: 14, fontWeight: 600 }}>{d.score}</span>
        <span style={{ fontSize: 11, fontWeight: 600, color: up >= 0 ? "var(--t-leading)" : "var(--accent)",
          display: "inline-flex", alignItems: "center", gap: 2, width: 34 }}>
          <Icon name={up >= 0 ? "arrowUp" : "arrowDn"} size={11} />{Math.abs(up)}
        </span>
      </div>
    </div>
  );
}

function ScoreDial({ score, size = 132 }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(score);
  const r = size / 2 - 9;
  const c = 2 * Math.PI * r;
  const animed = useCountUp(score, 1100);
  const off = c - (animed / 100) * c;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-inset)" strokeWidth="9" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tier.color} strokeWidth="9"
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off} style={{ transition: "stroke-dashoffset .2s linear" }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <span className="display tnum" style={{ fontSize: 40, lineHeight: 1 }}>{Math.round(animed)}</span>
        <span style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 2 }}>/ 100</span>
      </div>
    </div>
  );
}

function Dashboard({ go }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(D.overall);
  const trend = [54, 56, 58, 57, 60, 62, 63, 66, 68, 69, 71];
  const resume = D.sessions.find((s) => s.status === "in_progress");

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: 26 }}>

      {/* hero */}
      <div style={{ display: "grid", gridTemplateColumns: "1.55fr 1fr", gap: 18 }}>
        {/* maturity score panel */}
        <div className="card" style={{ padding: 22, display: "flex", gap: 26, alignItems: "center" }}>
          <ScoreDial score={D.overall} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
              <span className="eyebrow">Overall AI maturity</span>
              <TierChip tier={tier.key} size="sm" />
            </div>
            <p style={{ margin: "0 0 14px", fontSize: 14, color: "var(--muted)", lineHeight: 1.5, maxWidth: 340 }}>
              You're in the top <strong style={{ color: "var(--ink)" }}>18%</strong> of your sector. Governance & Risk is your biggest opportunity.
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
              <div style={{ flexShrink: 0 }}>
                <div style={{ fontSize: 11.5, color: "var(--faint)", marginBottom: 5 }}>12-month trend</div>
                <div style={{ width: 140 }}><Sparkline data={trend} w={140} h={34} color={tier.color} /></div>
              </div>
              <div style={{ width: 1, alignSelf: "stretch", background: "var(--border)" }} />
              <div style={{ display: "flex", flexDirection: "column", gap: 3, flexShrink: 0 }}>
                <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 14, fontWeight: 700, color: "var(--t-leading)", whiteSpace: "nowrap" }}>
                  <Icon name="arrowUp" size={13} /> +17 pts
                </span>
                <span style={{ fontSize: 11.5, color: "var(--faint)", whiteSpace: "nowrap" }}>since last year</span>
              </div>
            </div>
          </div>
        </div>

        {/* resume / next action */}
        <div className="card" style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "16px 18px 14px", borderBottom: "1px solid var(--border)" }}>
            <span className="eyebrow">Continue</span>
          </div>
          <div style={{ padding: 18, display: "flex", flexDirection: "column", gap: 14, flex: 1 }}>
            {resume && (
              <React.Fragment>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
                    <span style={{ width: 7, height: 7, borderRadius: 999, background: "var(--t-developing)" }} />
                    <span style={{ fontSize: 11.5, color: "var(--faint)" }}>{resume.date}</span>
                  </div>
                  <h3 style={{ fontSize: 15.5, fontWeight: 600, marginBottom: 10 }}>{resume.assessment}</h3>
                  <div style={{ height: 6, borderRadius: 999, background: "var(--surface-inset)", overflow: "hidden", boxShadow: "var(--inner-line)" }}>
                    <div style={{ width: resume.progress + "%", height: "100%", background: "var(--accent)", borderRadius: 999 }} />
                  </div>
                  <div style={{ fontSize: 11.5, color: "var(--muted)", marginTop: 6 }}>{resume.progress}% complete · ~10 min left</div>
                </div>
                <button className="btn btn-primary" style={{ marginTop: "auto", justifyContent: "center" }} onClick={() => go("quiz")}>
                  <Icon name="play" size={14} fill /> Resume assessment
                </button>
              </React.Fragment>
            )}
          </div>
        </div>
      </div>

      {/* metrics */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        <MetricCard label="Assessments" value="3" delta="+1" up icon="layers" />
        <MetricCard label="Sector percentile" value="82" suffix="nd" delta="+9" up icon="target" />
        <MetricCard label="Dimensions improving" value="6" suffix="/ 6" delta="+2" up icon="trend" />
        <MetricCard label="Days to reassess" value="38" note="On track" up icon="clock" />
      </div>

      {/* dimension matrix */}
      <div className="card" style={{ padding: 22 }}>
        <SectionHead title="Maturity by dimension" sub="Scored 0–100 across the four maturity tiers."
          action={<button className="btn btn-soft" onClick={() => go("report")}>View full report <Icon name="arrowR" size={14} /></button>} />
        {/* tier legend */}
        <div style={{ display: "flex", gap: 18, marginBottom: 6, paddingLeft: 184 }}>
          {D.tiers.map((t) => (
            <span key={t.key} style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11, color: "var(--muted)" }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: t.color }} />{t.label}
              <span className="mono" style={{ color: "var(--faint)" }}>{t.range[0]}–{t.range[1]}</span>
            </span>
          ))}
        </div>
        <div style={{ borderTop: "1px solid var(--border)" }}>
          {D.dimensions.map((d, i) => <DimensionRow key={d.id} d={d} delay={i * 90} />)}
        </div>
      </div>

      {/* two column: assessments + sessions */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <div>
          <SectionHead title="Available assessments" />
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {D.assessments.map((a) => (
              <div key={a.id} className="card" style={{ padding: 16, display: "flex", flexDirection: "column", gap: 10, cursor: "pointer" }}
                onClick={() => go("quiz")}
                onMouseEnter={(e) => e.currentTarget.style.boxShadow = "var(--card-shadow-hover)"}
                onMouseLeave={(e) => e.currentTarget.style.boxShadow = "var(--card-shadow)"}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                  <div>
                    <h3 style={{ fontSize: 14.5, fontWeight: 600, marginBottom: 4 }}>{a.name}</h3>
                    <p style={{ margin: 0, fontSize: 12.5, color: "var(--muted)", lineHeight: 1.45 }}>{a.desc}</p>
                  </div>
                  {a.tier !== "free" && <span style={{ color: "var(--faint)", flexShrink: 0 }}><Icon name="lock" size={14} /></span>}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 11.5, color: "var(--faint)" }}>
                  <span className="mono">v{a.version}</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><Icon name="doc" size={12} />{a.questions} questions</span>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><Icon name="clock" size={12} />{a.mins} min</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <SectionHead title="Recent sessions" action={<button className="btn btn-soft" onClick={() => go("sessions")}>All <Icon name="arrowR" size={14} /></button>} />
          <div className="card" style={{ overflow: "hidden" }}>
            {D.sessions.filter((s) => s.status === "completed").map((s, i, arr) => (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 16px",
                borderBottom: i < arr.length - 1 ? "1px solid var(--border)" : "none", cursor: "pointer" }}
                onClick={() => go("report")}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: "var(--surface-inset)", display: "flex", alignItems: "center",
                  justifyContent: "center", color: "var(--muted)", flexShrink: 0 }}>
                  <Icon name="report" size={17} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.assessment}</div>
                  <div style={{ fontSize: 11.5, color: "var(--faint)" }}>{s.date}</div>
                </div>
                <span className="mono tnum" style={{ fontSize: 15, fontWeight: 600 }}>{s.score}</span>
                <TierChip tier={s.tier} size="sm" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard, SectionHead, MetricCard, ScoreDial, DimensionRow });
