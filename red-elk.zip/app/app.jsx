/* Red Elk — app shell + router + tweaks */

const NAV = [
  { id: "dashboard", label: "Dashboard", icon: "dashboard" },
  { id: "report", label: "Report", icon: "report" },
  { id: "plan", label: "Action plan", icon: "flag" },
  { id: "benchmarks", label: "Benchmarks", icon: "target" },
  { id: "quiz", label: "Take assessment", icon: "compass" },
  { id: "sessions", label: "My sessions", icon: "sessions" },
];
const ADMIN_NAV = [
  { id: "admin", label: "Analytics", icon: "analytics" },
  { id: "adminSessions", label: "All sessions", icon: "sessions" },
  { id: "adminUsers", label: "Users", icon: "users" },
  { id: "adminImport", label: "Import", icon: "upload" },
];
const TITLES = {
  dashboard: ["Overview", "Your AI maturity at a glance"],
  report: ["Assessment report", "Enterprise AI Maturity · 8 Jun 2026"],
  plan: ["Action plan", "Your prioritised roadmap to the next maturity tier"],
  benchmarks: ["Benchmarks", "How you compare against sector peers"],
  quiz: ["Enterprise AI Maturity", "Answer honestly — there are no wrong answers"],
  sessions: ["My sessions", "Your assessment history"],
  admin: ["Platform analytics", "Across all companies and assessments"],
};

function Sidebar({ screen, go }) {
  function Item({ n }) {
    const active = screen === n.id || (n.id === "report" && screen === "report");
    return (
      <button onClick={() => go(n.id)} style={{
        display: "flex", alignItems: "center", gap: 11, width: "100%", textAlign: "left", cursor: "pointer",
        padding: "9px 11px", borderRadius: 10, border: "none", marginBottom: 2,
        fontFamily: "var(--font-ui)", fontSize: 13.5, fontWeight: active ? 600 : 500,
        background: active ? "var(--sidebar-active-bg)" : "transparent",
        color: active ? "var(--sidebar-active-ink)" : "var(--sidebar-muted)",
        transition: "all .15s var(--ease)",
      }}
        onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = "color-mix(in srgb, var(--sidebar-ink) 6%, transparent)"; e.currentTarget.style.color = "var(--sidebar-ink)"; } }}
        onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--sidebar-muted)"; } }}>
        <Icon name={n.icon} size={17} />
        <span style={{ flex: 1 }}>{n.label}</span>
        {active && <Icon name="chevR" size={13} style={{ opacity: .5 }} />}
      </button>
    );
  }
  return (
    <aside style={{ width: 240, flexShrink: 0, background: "var(--sidebar-bg)", borderRight: "1px solid var(--sidebar-border)",
      height: "100vh", position: "sticky", top: 0, display: "flex", flexDirection: "column", padding: "18px 14px" }}>
      {/* brand */}
      <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "4px 8px 18px" }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: "var(--sidebar-brand-tile)", display: "flex",
          alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0, boxShadow: "0 1px 2px rgba(0,0,0,.12)" }}>
          <img src="assets/logo.svg" alt="Red Elk" style={{ width: 34, height: 34, objectFit: "cover" }} />
        </div>
        <div>
          <div style={{ fontSize: 14.5, fontWeight: 700, color: "var(--sidebar-ink)", letterSpacing: "-.01em" }}>Red Elk</div>
          <div style={{ fontSize: 10.5, color: "var(--sidebar-muted)", letterSpacing: ".02em" }}>AI MATURITY</div>
        </div>
      </div>

      <nav style={{ flex: 1, overflowY: "auto" }}>
        <div style={{ padding: "0 11px 6px" }}><span className="eyebrow" style={{ color: "var(--sidebar-muted)", opacity: .8 }}>Workspace</span></div>
        {NAV.map((n) => <Item key={n.id} n={n} />)}
        <div style={{ padding: "16px 11px 6px" }}><span className="eyebrow" style={{ color: "var(--sidebar-muted)", opacity: .8 }}>Admin</span></div>
        {ADMIN_NAV.map((n) => <Item key={n.id} n={n} />)}
      </nav>

      {/* user */}
      <div style={{ borderTop: "1px solid var(--sidebar-border)", paddingTop: 12, marginTop: 8 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 8px" }}>
          <div style={{ width: 32, height: 32, borderRadius: 999, background: "var(--accent)", color: "#fff", flexShrink: 0,
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>AV</div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: "var(--sidebar-ink)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>Ava Lindqvist</div>
            <div style={{ fontSize: 11, color: "var(--sidebar-muted)" }}>Northwind · Admin</div>
          </div>
          <button style={{ background: "transparent", border: "none", color: "var(--sidebar-muted)", cursor: "pointer", padding: 4, display: "flex" }}><Icon name="logout" size={16} /></button>
        </div>
      </div>
    </aside>
  );
}

function Topbar({ screen }) {
  const [title, sub] = TITLES[screen] || TITLES.dashboard;
  return (
    <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 20,
      padding: "20px 32px", borderBottom: "1px solid var(--border)", background: "color-mix(in srgb, var(--bg) 72%, transparent)",
      backdropFilter: "blur(8px)", position: "sticky", top: 0, zIndex: 5 }}>
      <div>
        <h1 className="display" style={{ fontSize: 23, lineHeight: 1.1 }}>{title}</h1>
        <p style={{ margin: "3px 0 0", fontSize: 12.5, color: "var(--muted)" }}>{sub}</p>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 13px", borderRadius: "var(--radius)",
          background: "var(--surface)", border: "1px solid var(--border)", color: "var(--faint)", width: 210 }}>
          <Icon name="search" size={15} />
          <span style={{ fontSize: 13 }}>Search…</span>
          <span className="mono" style={{ marginLeft: "auto", fontSize: 10.5, padding: "1px 5px", borderRadius: 5, background: "var(--surface-inset)", color: "var(--faint)" }}>⌘K</span>
        </div>
        <button className="btn btn-ghost" style={{ padding: "8px", borderRadius: "var(--radius)" }}><Icon name="bell" size={17} /></button>
        <button className="btn btn-primary"><Icon name="plus" size={15} /> New assessment</button>
      </div>
    </header>
  );
}

/* ---------- Tweaks ---------- */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "direction": "atlas",
  "density": "regular",
  "accent": "#C2362B"
}/*EDITMODE-END*/;

const DIRECTIONS = [
  { id: "ledger", name: "Ledger", desc: "Editorial fintech · serif numerals" },
  { id: "console", name: "Console", desc: "Technical · dark rail · dense" },
  { id: "atlas", name: "Atlas", desc: "Brand-forward · maroon · warm" },
];
const ACCENTS = { ledger: ["#C2362B", "#B5232A", "#A8431F"], console: ["#C0392B", "#2D6CDF", "#1F8A5B"], atlas: ["#B5232A", "#8E1820", "#A8431F"] };

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [screen, setScreen] = useState(() => (location.hash || "").replace("#", "") || "dashboard");

  useEffect(() => {
    document.documentElement.setAttribute("data-dir", t.direction);
    document.documentElement.setAttribute("data-density", t.density);
  }, [t.direction, t.density]);
  useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);
  // reset accent to the direction's default when the user switches direction (skip first mount)
  const firstDir = useRef(true);
  useEffect(() => {
    if (firstDir.current) { firstDir.current = false; return; }
    setTweak("accent", ACCENTS[t.direction][0]);
  }, [t.direction]);

  useEffect(() => {
    const onHash = () => { const s = (location.hash || "").replace("#", ""); if (s) setScreen(s); };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const go = (id) => { setScreen(id); try { history.replaceState(null, "", "#" + id); } catch (e) {} window.scrollTo({ top: 0 }); };

  const Screen = { dashboard: Dashboard, report: Report, quiz: Quiz, admin: Admin, plan: ActionPlan, benchmarks: Benchmarks }[screen]
    || (() => <Placeholder screen={screen} />);

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg)",
      backgroundImage: "var(--texture)", backgroundSize: "var(--texture-size, 22px 22px)" }}>
      <Sidebar screen={screen} go={go} />
      <main style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <Topbar screen={screen} />
        <div style={{ padding: "28px 32px 64px", maxWidth: 1180, width: "100%", margin: "0 auto", flex: 1 }}>
          <Screen go={go} key={screen + t.direction} />
        </div>
      </main>

      <TweaksPanel>
        <TweakSection label="Design direction" />
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {DIRECTIONS.map((d) => {
            const on = t.direction === d.id;
            return (
              <button key={d.id} onClick={() => setTweak("direction", d.id)} style={{
                display: "flex", alignItems: "center", gap: 11, textAlign: "left", cursor: "pointer", width: "100%",
                padding: "11px 12px", borderRadius: 10, fontFamily: "var(--font-ui)",
                border: "1.5px solid " + (on ? "var(--accent)" : "var(--border)"),
                background: on ? "var(--accent-soft)" : "var(--surface)", transition: "all .15s" }}>
                <span style={{ display: "flex", gap: 3 }}>
                  {ACCENTS[d.id].slice(0, 3).map((c, i) => <span key={i} style={{ width: 10, height: 22, borderRadius: 3, background: c, opacity: i === 0 ? 1 : .45 }} />)}
                </span>
                <span style={{ flex: 1 }}>
                  <span style={{ display: "block", fontSize: 13.5, fontWeight: 600, color: on ? "var(--accent-press)" : "var(--ink)" }}>{d.name}</span>
                  <span style={{ display: "block", fontSize: 11, color: "var(--muted)" }}>{d.desc}</span>
                </span>
                {on && <span style={{ color: "var(--accent)", display: "flex" }}><Icon name="check" size={16} /></span>}
              </button>
            );
          })}
        </div>
        <TweakSection label="Accent" />
        <TweakColor label="Brand color" value={t.accent} options={ACCENTS[t.direction]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Density" />
        <TweakRadio label="Spacing" value={t.density} options={["compact", "regular", "comfy"]} onChange={(v) => setTweak("density", v)} />
      </TweaksPanel>
    </div>
  );
}

function Placeholder({ screen }) {
  const [title] = TITLES[screen] || ["Coming soon"];
  return (
    <div className="card fade-in" style={{ padding: 48, textAlign: "center", color: "var(--muted)" }}>
      <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--surface-inset)", color: "var(--faint)",
        display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="layers" size={24} /></div>
      <h2 style={{ fontSize: 18, fontWeight: 600, color: "var(--ink)", marginBottom: 6 }}>{title}</h2>
      <p style={{ margin: 0, fontSize: 13.5 }}>This screen isn't part of the current redesign pass.<br />Dashboard, Report, Take assessment and Analytics are wired up.</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
