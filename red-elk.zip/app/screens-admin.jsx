/* Red Elk — Admin analytics screen */

function AreaChart({ data, h = 190, color = "var(--accent)" }) {
  const wrap = useRef(null);
  const [w, setW] = useState(640);
  useEffect(() => {
    if (!wrap.current) return;
    const ro = new ResizeObserver((e) => setW(e[0].contentRect.width));
    ro.observe(wrap.current);
    return () => ro.disconnect();
  }, []);
  const pad = { t: 12, r: 8, b: 24, l: 30 };
  const iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
  const max = 70, min = 30;
  const step = iw / (data.length - 1);
  const [grow, setGrow] = useState(0);
  useEffect(() => { const t = setTimeout(() => setGrow(1), 80); return () => clearTimeout(t); }, []);
  const xy = (v, i) => [pad.l + i * step, pad.t + ih - ((v - min) / (max - min)) * ih];
  const pts = data.map((v, i) => xy(v, i));
  const line = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const area = line + ` L${pad.l + iw} ${pad.t + ih} L${pad.l} ${pad.t + ih} Z`;
  const months = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
  return (
    <div ref={wrap} style={{ width: "100%" }}>
      <svg width={w} height={h}>
        <defs>
          <linearGradient id="adminArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.18" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[30, 40, 50, 60, 70].map((g) => {
          const y = pad.t + ih - ((g - min) / (max - min)) * ih;
          return (
            <g key={g}>
              <line x1={pad.l} y1={y} x2={pad.l + iw} y2={y} stroke="var(--border)" strokeWidth="1" />
              <text x={pad.l - 8} y={y + 3} textAnchor="end" style={{ fontSize: 9.5, fill: "var(--faint)", fontFamily: "var(--font-mono)" }}>{g}</text>
            </g>
          );
        })}
        <g style={{ clipPath: `inset(0 ${(1 - grow) * 100}% 0 0)`, transition: "clip-path 1.1s var(--ease)" }}>
          <path d={area} fill="url(#adminArea)" />
          <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3.2" fill={color}
          style={{ opacity: grow, transition: "opacity .3s ease 1s" }} />
        {months.map((m, i) => (
          <text key={i} x={pad.l + i * step} y={h - 7} textAnchor="middle" style={{ fontSize: 9.5, fill: "var(--faint)", fontFamily: "var(--font-mono)" }}>{m}</text>
        ))}
      </svg>
    </div>
  );
}

function Donut({ dist, size = 150 }) {
  const r = size / 2 - 14, c = 2 * Math.PI * r;
  let acc = 0;
  const [grow, setGrow] = useState(0);
  useEffect(() => { const t = setTimeout(() => setGrow(1), 100); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        {dist.map((d, i) => {
          const len = (d.pct / 100) * c * grow;
          const seg = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={d.color} strokeWidth="14"
            strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-acc} style={{ transition: "stroke-dasharray 1s var(--ease)" }} />;
          acc += (d.pct / 100) * c * grow;
          return seg;
        })}
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <span className="display tnum" style={{ fontSize: 26 }}>208</span>
        <span style={{ fontSize: 10, color: "var(--faint)" }}>companies</span>
      </div>
    </div>
  );
}

function AdminBar({ d, i }) {
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(d.v), 100 + i * 70); return () => clearTimeout(t); }, []);
  const D = window.RE_DATA;
  const tier = D.tierOf(d.v);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "160px 1fr 34px", alignItems: "center", gap: 14, padding: "9px 0" }}>
      <span style={{ fontSize: 12.5, fontWeight: 500 }}>{d.label}</span>
      <div style={{ height: 8, borderRadius: 999, background: "var(--surface-inset)", overflow: "hidden", boxShadow: "var(--inner-line)" }}>
        <div style={{ width: w + "%", height: "100%", background: tier.color, borderRadius: 999, transition: "width .9s var(--ease)" }} />
      </div>
      <span className="mono tnum" style={{ fontSize: 12.5, fontWeight: 600, textAlign: "right" }}>{d.v}</span>
    </div>
  );
}

function Admin({ go }) {
  const A = window.RE_DATA.admin;
  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: 22 }}>

      {/* stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        {A.stats.map((s) => (
          <div key={s.label} className="card" style={{ padding: "16px 17px", display: "flex", flexDirection: "column", gap: 8 }}>
            <span className="eyebrow">{s.label}</span>
            <span className="display tnum" style={{ fontSize: 30, lineHeight: 1 }}>{s.value}</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 600,
              color: s.up ? "var(--t-leading)" : "var(--accent)" }}>
              <Icon name={s.up ? "arrowUp" : "arrowDn"} size={12} />{s.delta}
            </span>
          </div>
        ))}
      </div>

      {/* trend + distribution */}
      <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 18 }}>
        <div className="card" style={{ padding: 22 }}>
          <SectionHead title="Average maturity score" sub="Platform-wide, trailing 12 months"
            action={<TierChip tier="maturing" size="sm" />} />
          <AreaChart data={A.trend} color="var(--accent)" />
        </div>
        <div className="card" style={{ padding: 22 }}>
          <SectionHead title="Maturity distribution" />
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <Donut dist={A.distribution} />
            <div style={{ display: "flex", flexDirection: "column", gap: 9, flex: 1 }}>
              {A.distribution.map((d) => (
                <div key={d.tier} style={{ display: "flex", alignItems: "center", gap: 9 }}>
                  <span style={{ width: 9, height: 9, borderRadius: 3, background: d.color }} />
                  <span style={{ fontSize: 12.5, flex: 1 }}>{d.tier}</span>
                  <span className="mono tnum" style={{ fontSize: 12.5, fontWeight: 600 }}>{d.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* dimension averages + recent */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.25fr", gap: 18 }}>
        <div className="card" style={{ padding: 22 }}>
          <SectionHead title="Weakest dimensions" sub="Where companies struggle most" />
          <div style={{ borderTop: "1px solid var(--border)" }}>
            {[...A.dimAverages].sort((a, b) => a.v - b.v).map((d, i) => <AdminBar key={d.label} d={d} i={i} />)}
          </div>
        </div>

        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "18px 22px 14px" }}>
            <SectionHead title="Recent assessments" action={<button className="btn btn-soft">Export <Icon name="download" size={13} /></button>} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto auto", padding: "0 22px 8px", gap: 12 }}>
            {["Company", "Score", "Tier", "Date"].map((h, i) => (
              <span key={h} className="eyebrow" style={{ textAlign: i === 0 ? "left" : "right" }}>{h}</span>
            ))}
          </div>
          <div>
            {A.recent.map((r, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr auto auto auto", gap: 12, alignItems: "center",
                padding: "12px 22px", borderTop: "1px solid var(--border)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 11, minWidth: 0 }}>
                  <span style={{ width: 32, height: 32, borderRadius: 9, background: "var(--surface-inset)", color: "var(--muted)", flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="building" size={15} /></span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.co}</div>
                    <div style={{ fontSize: 11, color: "var(--faint)" }}>{r.sector}</div>
                  </div>
                </div>
                <span className="mono tnum" style={{ fontSize: 13.5, fontWeight: 600, textAlign: "right", width: 30 }}>{r.score}</span>
                <div style={{ textAlign: "right" }}><TierChip tier={r.tier} size="sm" /></div>
                <span className="mono" style={{ fontSize: 11.5, color: "var(--faint)", textAlign: "right", width: 40 }}>{r.date}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Admin });
