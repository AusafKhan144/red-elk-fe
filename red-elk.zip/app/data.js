/* Red Elk — sample data (plain global) */
window.RE_DATA = (function () {
  const dimensions = [
    { id: "strategy",   label: "Strategy & Vision",        score: 82, prev: 74,
      note: "Clear AI ambition with executive sponsorship and a funded roadmap." },
    { id: "data",       label: "Data & Infrastructure",    score: 71, prev: 63,
      note: "Pipelines are consolidating; governance of training data still maturing." },
    { id: "technology", label: "Technology & Tooling",     score: 79, prev: 70,
      note: "Modern ML stack in place; MLOps automation partially adopted." },
    { id: "talent",     label: "Talent & Skills",          score: 64, prev: 61,
      note: "Core team strong, but AI literacy is uneven across business units." },
    { id: "governance", label: "Governance & Risk",        score: 58, prev: 49,
      note: "Policy framework drafted; model monitoring not yet systematic." },
    { id: "adoption",   label: "Adoption & Culture",       score: 73, prev: 58,
      note: "Strong pilot momentum; scaling playbook being formalised." },
  ];

  const overall = Math.round(dimensions.reduce((s, d) => s + d.score, 0) / dimensions.length);

  const tiers = [
    { key: "nascent",    label: "Nascent",    range: [0, 30],  color: "var(--t-nascent)" },
    { key: "developing", label: "Developing", range: [30, 55], color: "var(--t-developing)" },
    { key: "maturing",   label: "Maturing",   range: [55, 75], color: "var(--t-maturing)" },
    { key: "leading",    label: "Leading",    range: [75, 100],color: "var(--t-leading)" },
  ];

  function tierOf(score) {
    return tiers.find((t) => score >= t.range[0] && score < t.range[1]) || tiers[tiers.length - 1];
  }

  const assessments = [
    { id: "a1", name: "Enterprise AI Maturity", slug: "enterprise-ai-maturity", version: 3,
      questions: 48, mins: 25, tier: "premium",
      desc: "The full diagnostic across six capability dimensions, benchmarked against your sector." },
    { id: "a2", name: "Data Readiness Index", slug: "data-readiness", version: 2,
      questions: 24, mins: 12, tier: "basic",
      desc: "Assess data quality, governance and infrastructure readiness for AI workloads." },
    { id: "a3", name: "Responsible AI Checkpoint", slug: "responsible-ai", version: 1,
      questions: 18, mins: 10, tier: "free",
      desc: "A focused review of governance, risk controls and model accountability." },
  ];

  const sessions = [
    { id: "s1", assessment: "Enterprise AI Maturity", status: "completed", score: 71, tier: "leading",
      date: "8 Jun 2026", by: "You" },
    { id: "s2", assessment: "Data Readiness Index", status: "completed", score: 64, tier: "maturing",
      date: "2 Jun 2026", by: "You" },
    { id: "s3", assessment: "Enterprise AI Maturity", status: "in_progress", progress: 60,
      date: "Started 2 days ago", by: "You" },
    { id: "s4", assessment: "Responsible AI Checkpoint", status: "completed", score: 52, tier: "developing",
      date: "21 May 2026", by: "You" },
  ];

  // quiz
  const quiz = {
    assessment: "Enterprise AI Maturity",
    dimension: "Governance & Risk",
    index: 14, total: 48,
    question: "How systematically does your organisation monitor deployed AI models for drift, bias and performance degradation?",
    help: "Consider whether monitoring is automated, how often models are reviewed, and who is accountable.",
    options: [
      { v: 1, label: "No monitoring", desc: "Models run without ongoing oversight." },
      { v: 2, label: "Ad hoc checks", desc: "Reviewed manually when issues are reported." },
      { v: 3, label: "Scheduled reviews", desc: "Periodic manual review on a fixed cadence." },
      { v: 4, label: "Mostly automated", desc: "Automated alerting for most production models." },
      { v: 5, label: "Fully systematic", desc: "Continuous automated monitoring with clear ownership." },
    ],
  };

  // admin analytics
  const admin = {
    stats: [
      { label: "Total assessments", value: "1,284", delta: "+12.4%", up: true },
      { label: "Active companies", value: "208", delta: "+6.1%", up: true },
      { label: "Avg. maturity score", value: "61.8", delta: "+3.2", up: true },
      { label: "Completion rate", value: "78%", delta: "-1.4%", up: false },
    ],
    dimAverages: [
      { label: "Strategy & Vision",     v: 68 },
      { label: "Data & Infrastructure", v: 57 },
      { label: "Technology & Tooling",  v: 64 },
      { label: "Talent & Skills",       v: 52 },
      { label: "Governance & Risk",     v: 46 },
      { label: "Adoption & Culture",    v: 60 },
    ],
    distribution: [
      { tier: "Nascent",    pct: 14, color: "var(--t-nascent)" },
      { tier: "Developing", pct: 31, color: "var(--t-developing)" },
      { tier: "Maturing",   pct: 39, color: "var(--t-maturing)" },
      { tier: "Leading",    pct: 16, color: "var(--t-leading)" },
    ],
    trend: [42, 45, 44, 48, 51, 50, 54, 57, 56, 59, 61, 62],
    recent: [
      { co: "Northwind Logistics", sector: "Supply Chain", score: 74, tier: "maturing", date: "9 Jun" },
      { co: "Halcyon Health",      sector: "Healthcare",   score: 81, tier: "leading",  date: "9 Jun" },
      { co: "Meridian Capital",    sector: "Financial",    score: 66, tier: "maturing", date: "8 Jun" },
      { co: "Arbor Retail Group",  sector: "Retail",       score: 49, tier: "developing",date: "8 Jun" },
      { co: "Quill & Co.",         sector: "Media",        score: 38, tier: "developing",date: "7 Jun" },
    ],
  };

  // action plan — initiatives derived from the report
  const actionPlan = {
    summary: { initiatives: 6, quickWins: 2, estLift: 14 },
    items: [
      { id: "p1", title: "Stand up automated model monitoring", dimension: "Governance & Risk",
        impact: "High", effort: "Medium", weeks: 8, status: "recommended", owner: "Platform / MLOps",
        desc: "Deploy drift, bias and performance alerting across all production models with clear ownership.", lift: 9 },
      { id: "p2", title: "Establish a formal AI risk register", dimension: "Governance & Risk",
        impact: "High", effort: "Low", weeks: 4, status: "quick-win", owner: "Risk & Compliance",
        desc: "Catalogue every deployed model, its owner, data sources, and known risks in one reviewed register.", lift: 5 },
      { id: "p3", title: "Run an org-wide AI literacy program", dimension: "Talent & Skills",
        impact: "Medium", effort: "Medium", weeks: 12, status: "recommended", owner: "People / L&D",
        desc: "Role-based training so business units can identify and scope AI opportunities confidently.", lift: 7 },
      { id: "p4", title: "Consolidate the training-data catalogue", dimension: "Data & Infrastructure",
        impact: "Medium", effort: "High", weeks: 16, status: "planned", owner: "Data Engineering",
        desc: "Single governed catalogue with lineage and quality scoring for all AI training data.", lift: 6 },
      { id: "p5", title: "Publish a model deployment checklist", dimension: "Governance & Risk",
        impact: "Medium", effort: "Low", weeks: 3, status: "quick-win", owner: "MLOps",
        desc: "A required pre-launch checklist covering review, monitoring and rollback for every model.", lift: 4 },
      { id: "p6", title: "Formalise the scaling playbook", dimension: "Adoption & Culture",
        impact: "Medium", effort: "Medium", weeks: 10, status: "planned", owner: "Transformation Office",
        desc: "Codify how successful pilots graduate to production so momentum compounds.", lift: 5 },
    ],
  };

  // benchmarks — you vs sector peers
  const benchmarks = {
    sector: "Financial Services", peers: 208, percentile: 82,
    dims: [
      { label: "Strategy & Vision",     you: 82, sector: 64, top: 86 },
      { label: "Data & Infrastructure", you: 71, sector: 58, top: 81 },
      { label: "Technology & Tooling",  you: 79, sector: 62, top: 84 },
      { label: "Talent & Skills",       you: 64, sector: 55, top: 78 },
      { label: "Governance & Risk",     you: 58, sector: 51, top: 80 },
      { label: "Adoption & Culture",    you: 73, sector: 57, top: 79 },
    ],
  };

  return { dimensions, overall, tiers, tierOf, assessments, sessions, quiz, admin, actionPlan, benchmarks };
})();
