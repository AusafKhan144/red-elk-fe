/* Red Elk — Action Plan + Benchmarks screens */

const STATUS_META = {
  "quick-win":   { label: "Quick win",   color: "var(--t-leading)" },
  "recommended": { label: "Recommended", color: "var(--accent)" },
  "planned":     { label: "Planned",     color: "var(--t-maturing)" },
};
const IMPACT_DOTS = { High: 3, Medium: 2, Low: 1 };

function MetaPill({ label, value, color }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 11.5, color: "var(--muted)" }}>
      <span style={{ color: "var(--faint)" }}>{label}</span>
      <span style={{ fontWeight: 600, color: color || "var(--ink)" }}>{value}</span>
    </span>
  );
}

function InitiativeCard({ it }) {
  const st = STATUS_META[it.status];
  return (
    <div className="card" style={{ padding: 0, overflow: "hidden", display: "flex" }}>
      <div style={{ width: 4, background: st.color, flexShrink: 0 }} />
      <div style={{ padding: 18, flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 14 }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
              <span className="chip" style={{ fontSize: 11, padding: "2px 9px 2px 8px", color: st.color,
                background: "color-mix(in srgb, " + st.color + " 11%, var(--surface))",
                borderColor: "color-mix(in srgb, " + st.color + " 26%, transparent)" }}>
                <span className="dot" style={{ background: st.color }} />{st.label}
              </span>
              <span style={{ fontSize: 11.5, color: "var(--faint)" }}>{it.dimension}</span>
            </div>
            <h3 style={{ fontSize: 15.5, fontWeight: 600, marginBottom: 6 }}>{it.title}</h3>
            <p style={{ margin: 0, fontSize: 13, color: "var(--muted)", lineHeight: 1.5, maxWidth: 560 }}>{it.desc}</p>
          </div>
          <div style={{ textAlign: "right", flexShrink: 0 }}>
            <div className="display tnum" style={{ fontSize: 26, color: "var(--t-leading)", lineHeight: 1 }}>+{it.lift}</div>
            <div style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 2 }}>pts lift</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 18, marginTop: 14, paddingTop: 13, borderTop: "1px solid var(--border)", flexWrap: "wrap" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11.5, color: "var(--muted)" }}>
            <span style={{ color: "var(--faint)" }}>Impact</span>
            <span style={{ display: "inline-flex", gap: 2 }}>
              {[1, 2, 3].map((n) => <span key={n} style={{ width: 6, height: 6, borderRadius: 999,
                background: n <= IMPACT_DOTS[it.impact] ? "var(--accent)" : "var(--border-strong)" }} />)}
            </span>
            <span style={{ fontWeight: 600 }}>{it.impact}</span>
          </span>
          <MetaPill label="Effort" value={it.effort} />
          <MetaPill label="Timeframe" value={"~" + it.weeks + " wks"} />
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11.5, color: "var(--muted)", marginLeft: "auto" }}>
            <Icon name="users" size={13} /> {it.owner}
          </span>
        </div>
      </div>
    </div>
  );
}

function ActionPlan({ go }) {
  const D = window.RE_DATA;
  const P = D.actionPlan;
  const projected = D.overall + P.summary.estLift;
  const items = [...P.items].sort((a, b) => {
    const order = { "quick-win": 0, "recommended": 1, "planned": 2 };
    return order[a.status] - order[b.status];
  });

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: 22 }}>

      {/* projected lift hero */}
      <div className="card" style={{ padding: 22, display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 24, alignItems: "center" }}>
        <div>
          <span className="eyebrow" style={{ color: "var(--accent)" }}>Recommended roadmap</span>
          <h1 className="display" style={{ fontSize: 26, margin: "8px 0 10px", lineHeight: 1.1 }}>
            Six moves to reach <span style={{ color: "var(--t-leading)" }}>Leading</span>
          </h1>
          <p style={{ margin: 0, fontSize: 13.5, color: "var(--muted)", lineHeight: 1.55, maxWidth: 440 }}>
            Prioritised from your assessment by projected impact and effort. Start with the two quick wins to build momentum.
          </p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
            <span style={{ fontSize: 12.5, color: "var(--muted)" }}>Projected maturity</span>
            <span style={{ fontSize: 12, color: "var(--faint)" }}>if completed</span>
          </div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
            <span className="mono tnum" style={{ fontSize: 22, color: "var(--faint)" }}>{D.overall}</span>
            <Icon name="arrowR" size={16} style={{ color: "var(--faint)" }} />
            <span className="display tnum" style={{ fontSize: 38, color: "var(--t-leading)", lineHeight: 1 }}>{projected}</span>
          </div>
          <div style={{ position: "relative", height: 10, borderRadius: 999, background: "var(--surface-inset)", overflow: "hidden", boxShadow: "var(--inner-line)" }}>
            <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: D.overall + "%", background: "var(--t-maturing)", borderRadius: 999 }} />
            <div style={{ position: "absolute", left: D.overall + "%", top: 0, bottom: 0, width: P.summary.estLift + "%",
              background: "repeating-linear-gradient(45deg, var(--t-leading), var(--t-leading) 4px, color-mix(in srgb, var(--t-leading) 65%, #fff) 4px, color-mix(in srgb, var(--t-leading) 65%, #fff) 8px)" }} />
          </div>
          <div style={{ display: "flex", gap: 18 }}>
            <MetaPill label="Initiatives" value={P.summary.initiatives} />
            <MetaPill label="Quick wins" value={P.summary.quickWins} color="var(--t-leading)" />
            <MetaPill label="Est. lift" value={"+" + P.summary.estLift + " pts"} color="var(--t-leading)" />
          </div>
        </div>
      </div>

      {/* initiative list */}
      <div>
        <SectionHead title="Prioritised initiatives" sub="Ordered by impact and speed to value."
          action={<button className="btn btn-soft" onClick={() => go("report")}><Icon name="report" size={13} /> Back to report</button>} />
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {items.map((it) => <InitiativeCard key={it.id} it={it} />)}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Benchmarks ---------------- */
function BenchRow({ d, delay }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(d.you);
  const [grow, setGrow] = useState(0);
  useEffect(() => { const t = setTimeout(() => setGrow(1), 100 + delay); return () => clearTimeout(t); }, []);
  const above = d.you - d.sector;
  return (
    <div style={{ padding: "15px 0", borderBottom: "1px solid var(--border)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
        <span style={{ fontSize: 13.5, fontWeight: 600 }}>{d.label}</span>
        <span style={{ fontSize: 11.5, fontWeight: 600, color: above >= 0 ? "var(--t-leading)" : "var(--accent)",
          display: "inline-flex", alignItems: "center", gap: 4 }}>
          <Icon name={above >= 0 ? "arrowUp" : "arrowDn"} size={12} />{Math.abs(above)} vs sector
        </span>
      </div>
      <div style={{ position: "relative", height: 24 }}>
        {/* baseline track */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 10, height: 4, borderRadius: 999, background: "var(--surface-inset)", boxShadow: "var(--inner-line)" }} />
        {/* your fill */}
        <div style={{ position: "absolute", left: 0, top: 10, height: 4, width: (d.you * grow) + "%", background: tier.color, borderRadius: 999, transition: "width .9s var(--ease)" }} />
        {/* sector avg marker */}
        <Marker pos={d.sector} color="var(--faint)" label="sector" />
        {/* top quartile marker */}
        <Marker pos={d.top} color="var(--border-strong)" label="top 25%" dim />
        {/* your marker */}
        <div style={{ position: "absolute", left: `calc(${d.you}% * ${grow})`, top: 0, transform: "translateX(-50%)", transition: "left .9s var(--ease)", textAlign: "center" }}>
          <div style={{ width: 14, height: 14, borderRadius: 999, background: tier.color, border: "3px solid var(--surface)", boxShadow: "0 1px 3px rgba(0,0,0,.2)", margin: "4px auto 0" }} />
        </div>
        <span className="mono tnum" style={{ position: "absolute", right: 0, top: -2, fontSize: 13, fontWeight: 700, color: tier.color }}>{d.you}</span>
      </div>
    </div>
  );
}
function Marker({ pos, color, label, dim }) {
  return (
    <div style={{ position: "absolute", left: pos + "%", top: 5, bottom: 0, transform: "translateX(-50%)" }}>
      <div style={{ width: 2, height: 14, background: color, borderRadius: 999, opacity: dim ? .8 : 1 }} />
    </div>
  );
}

function Benchmarks({ go }) {
  const D = window.RE_DATA;
  const B = D.benchmarks;
  const aboveCount = B.dims.filter((d) => d.you >= d.sector).length;

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: 22 }}>

      {/* hero */}
      <div className="card" style={{ padding: 22, display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 26, alignItems: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div className="display tnum" style={{ fontSize: 52, color: "var(--t-leading)", lineHeight: 1 }}>82<span style={{ fontSize: 22 }}>nd</span></div>
          <div style={{ fontSize: 11.5, color: "var(--faint)", marginTop: 2 }}>percentile</div>
        </div>
        <div>
          <span className="eyebrow">Sector benchmark</span>
          <h1 className="display" style={{ fontSize: 25, margin: "8px 0 8px", lineHeight: 1.1 }}>
            Ahead of {B.percentile}% of {B.sector} peers
          </h1>
          <p style={{ margin: 0, fontSize: 13.5, color: "var(--muted)", lineHeight: 1.5, maxWidth: 460 }}>
            Compared against {B.peers} organisations who completed the Enterprise AI Maturity assessment in your sector.
          </p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, minWidth: 132 }}>
          <div className="card" style={{ padding: "12px 14px", boxShadow: "none", background: "var(--surface-2)" }}>
            <div className="tnum" style={{ fontSize: 20, fontWeight: 700, color: "var(--t-leading)" }}>{aboveCount}/6</div>
            <div style={{ fontSize: 11, color: "var(--faint)" }}>dimensions above average</div>
          </div>
        </div>
      </div>

      {/* per-dimension comparison */}
      <div className="card" style={{ padding: 22 }}>
        <SectionHead title="How you compare, by capability"
          action={
            <div style={{ display: "flex", gap: 16, fontSize: 11.5, color: "var(--muted)" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 10, height: 10, borderRadius: 999, background: "var(--t-maturing)" }} /> You</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 2, height: 12, background: "var(--faint)" }} /> Sector avg</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 2, height: 12, background: "var(--border-strong)" }} /> Top 25%</span>
            </div>
          } />
        <div style={{ borderTop: "1px solid var(--border)" }}>
          {B.dims.map((d, i) => <BenchRow key={d.label} d={d} delay={i * 80} />)}
        </div>
      </div>

      <div className="card" style={{ padding: 20, display: "flex", gap: 16, alignItems: "center",
        background: "color-mix(in srgb, var(--t-leading) 6%, var(--surface))", borderColor: "color-mix(in srgb, var(--t-leading) 22%, var(--border))" }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: "color-mix(in srgb, var(--t-leading) 14%, var(--surface))", color: "var(--t-leading)",
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon name="trend" size={21} /></div>
        <div style={{ flex: 1 }}>
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 3 }}>You lead the sector on Strategy &amp; Technology</h3>
          <p style={{ margin: 0, fontSize: 13, color: "var(--muted)", lineHeight: 1.5 }}>Governance &amp; Risk is your only dimension within reach of the sector average — closing it would move you into the top decile.</p>
        </div>
        <button className="btn btn-primary" onClick={() => go("plan")}>See action plan <Icon name="arrowR" size={14} /></button>
      </div>
    </div>
  );
}

Object.assign(window, { ActionPlan, Benchmarks });
