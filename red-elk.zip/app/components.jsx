/* Red Elk — shared UI primitives (React, exported to window) */
const { useState, useEffect, useRef } = React;

/* ---- Icons (lucide-style, 1.6 stroke) ---- */
const ICONS = {
  dashboard: "M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z",
  sessions:  "M9 5h10M9 12h10M9 19h10M4.5 5h.01M4.5 12h.01M4.5 19h.01",
  report:    "M3 3v18h18M7 14l3-4 3 3 5-7",
  layers:    "M12 3 3 8l9 5 9-5zM3 13l9 5 9-5",
  users:     "M16 19v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M9 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6M22 19v-1a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11",
  upload:    "M12 15V3M7 8l5-5 5 5M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2",
  analytics: "M3 3v18h18M8 17v-5M13 17V7M18 17v-8",
  settings:  "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-2.7-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.2 5.4l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 2.7-1.1V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z",
  logout:    "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  search:    "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16M21 21l-4.3-4.3",
  bell:      "M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0",
  chevR:     "M9 18l6-6-6-6",
  arrowR:    "M5 12h14M13 6l6 6-6 6",
  arrowUp:   "M12 19V5M6 11l6-6 6 6",
  arrowDn:   "M12 5v14M6 13l6 6 6-6",
  check:     "M20 6 9 17l-5-5",
  play:      "M6 4l14 8-14 8z",
  download:  "M12 3v12M7 10l5 5 5-5M5 21h14",
  plus:      "M12 5v14M5 12h14",
  sparkle:   "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z",
  lock:      "M5 11h14v10H5zM8 11V7a4 4 0 1 1 8 0v4",
  calendar:  "M8 2v4M16 2v4M3 9h18M5 5h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z",
  info:      "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 11v5M12 8h.01",
  trend:     "M22 7l-8.5 8.5-5-5L2 17M16 7h6v6",
  shield:    "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z",
  database:  "M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6",
  cpu:       "M9 3v2M15 3v2M9 19v2M15 19v2M3 9h2M3 15h2M19 9h2M19 15h2M7 7h10v10H7zM10 10h4v4h-4z",
  target:    "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2",
  compass:   "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M16 8l-2.5 5.5L8 16l2.5-5.5z",
  x:         "M18 6 6 18M6 6l12 12",
  menu:      "M3 6h18M3 12h18M3 18h18",
  flag:      "M4 15s1-1 4-1 5 2 8 2 4-1 4-1V4s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22V4",
  clock:     "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 7v5l3 2",
  building:  "M3 21h18M5 21V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16M18 21V9h2a1 1 0 0 1 1 1v11M8 7h.01M8 11h.01M8 15h.01M11 7h.01M11 11h.01M11 15h.01",
  doc:       "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6",
};

function Icon({ name, size = 18, stroke = 1.6, fill = false, style, className }) {
  const d = ICONS[name];
  if (!d) return null;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24"
      fill={fill ? "currentColor" : "none"}
      stroke={fill ? "none" : "currentColor"}
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      style={style} className={className} aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

/* ---- Tier chip ---- */
const TIER_META = {
  nascent:    { label: "Nascent",    color: "var(--t-nascent)" },
  developing: { label: "Developing", color: "var(--t-developing)" },
  maturing:   { label: "Maturing",   color: "var(--t-maturing)" },
  leading:    { label: "Leading",    color: "var(--t-leading)" },
};
function TierChip({ tier, size = "md" }) {
  const m = TIER_META[tier] || TIER_META.developing;
  const pad = size === "sm" ? "2px 8px 2px 7px" : "3px 10px 3px 8px";
  const fs = size === "sm" ? 11 : 12;
  return (
    <span className="chip" style={{
      padding: pad, fontSize: fs,
      color: m.color,
      background: "color-mix(in srgb, " + m.color + " 11%, var(--surface))",
      borderColor: "color-mix(in srgb, " + m.color + " 26%, transparent)",
    }}>
      <span className="dot" style={{ background: m.color }} />
      {m.label}
    </span>
  );
}

/* ---- Sparkline ---- */
function Sparkline({ data, w = 120, h = 34, color = "var(--accent)", fillArea = true }) {
  const max = Math.max(...data), min = Math.min(...data);
  const rng = max - min || 1;
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => [i * step, h - ((v - min) / rng) * (h - 6) - 3]);
  const line = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const area = line + ` L${w} ${h} L0 ${h} Z`;
  const gid = "sg" + Math.random().toString(36).slice(2, 7);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: "block", overflow: "visible" }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.16" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fillArea && <path d={area} fill={`url(#${gid})`} />}
      <path d={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="2.4" fill={color} />
    </svg>
  );
}

/* ---- animated count-up number ---- */
function useCountUp(target, dur = 900) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf, start;
    const tick = (t) => {
      if (!start) start = t;
      const p = Math.min((t - start) / dur, 1);
      const e = 1 - Math.pow(1 - p, 3);
      setV(target * e);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, dur]);
  return v;
}

Object.assign(window, { Icon, TierChip, Sparkline, useCountUp, useState, useEffect, useRef, TIER_META });
