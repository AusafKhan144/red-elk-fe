/* Red Elk — Quiz / assessment-taking flow */
function Quiz({ go }) {
  const D = window.RE_DATA;
  const q = D.quiz;
  const [idx, setIdx] = useState(q.index);
  const [selected, setSelected] = useState(null);
  const pct = Math.round((idx / q.total) * 100);
  const dimsDone = [
    { label: "Strategy & Vision", done: true },
    { label: "Data & Infrastructure", done: true },
    { label: "Technology & Tooling", done: true },
    { label: "Talent & Skills", done: true },
    { label: "Governance & Risk", active: true },
    { label: "Adoption & Culture", done: false },
  ];

  function next() {
    if (selected == null) return;
    if (idx >= q.total - 1) { go("report"); return; }
    setIdx(idx + 1); setSelected(null);
  }

  return (
    <div className="fade-in" style={{ display: "grid", gridTemplateColumns: "232px 1fr", gap: 24, alignItems: "start" }}>

      {/* left rail: dimension progress */}
      <div className="card" style={{ padding: 18, position: "sticky", top: 0 }}>
        <span className="eyebrow">Your progress</span>
        <div className="display tnum" style={{ fontSize: 30, margin: "8px 0 2px" }}>{pct}%</div>
        <div style={{ fontSize: 12, color: "var(--faint)", marginBottom: 16 }}>Question {idx + 1} of {q.total}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {dimsDone.map((d, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 9px", borderRadius: 9,
              background: d.active ? "var(--accent-soft)" : "transparent" }}>
              <span style={{ width: 18, height: 18, borderRadius: 999, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
                background: d.done ? "var(--t-leading)" : d.active ? "var(--accent)" : "var(--surface-inset)",
                color: (d.done || d.active) ? "#fff" : "var(--faint)", boxShadow: d.active ? "none" : "var(--inner-line)" }}>
                {d.done ? <Icon name="check" size={11} /> : <span style={{ width: 5, height: 5, borderRadius: 999, background: "currentColor" }} />}
              </span>
              <span style={{ fontSize: 12.5, fontWeight: d.active ? 600 : 500,
                color: d.active ? "var(--accent)" : d.done ? "var(--ink)" : "var(--faint)" }}>{d.label}</span>
            </div>
          ))}
        </div>
        <button className="btn btn-soft" style={{ width: "100%", justifyContent: "center", marginTop: 16 }} onClick={() => go("dashboard")}>
          Save &amp; exit
        </button>
      </div>

      {/* question panel */}
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ height: 4, background: "var(--surface-inset)" }}>
            <div style={{ width: pct + "%", height: "100%", background: "var(--accent)", transition: "width .5s var(--ease)" }} />
          </div>
          <div style={{ padding: 28 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
              <span className="chip" style={{ color: "var(--t-maturing)", background: "color-mix(in srgb, var(--t-maturing) 11%, var(--surface))",
                borderColor: "color-mix(in srgb, var(--t-maturing) 26%, transparent)" }}>
                <Icon name="shield" size={12} /> {q.dimension}
              </span>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 600, lineHeight: 1.32, letterSpacing: "-.01em", maxWidth: 640 }}>{q.question}</h1>
            <p style={{ margin: "12px 0 0", fontSize: 13.5, color: "var(--muted)", display: "flex", gap: 8, maxWidth: 580 }}>
              <span style={{ color: "var(--faint)", flexShrink: 0, marginTop: 1 }}><Icon name="info" size={15} /></span>
              {q.help}
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 24 }}>
              {q.options.map((o) => {
                const on = selected === o.v;
                return (
                  <button key={o.v} onClick={() => setSelected(o.v)}
                    style={{ display: "flex", alignItems: "center", gap: 14, textAlign: "left", cursor: "pointer",
                      padding: "14px 16px", borderRadius: "var(--radius)", width: "100%",
                      border: "1.5px solid " + (on ? "var(--accent)" : "var(--border)"),
                      background: on ? "var(--accent-soft)" : "var(--surface)",
                      transition: "all .15s var(--ease)", fontFamily: "var(--font-ui)" }}>
                    <span className="mono" style={{ width: 30, height: 30, borderRadius: 8, flexShrink: 0, display: "flex", alignItems: "center",
                      justifyContent: "center", fontSize: 13, fontWeight: 600,
                      background: on ? "var(--accent)" : "var(--surface-inset)", color: on ? "#fff" : "var(--muted)",
                      boxShadow: on ? "none" : "var(--inner-line)" }}>{o.v}</span>
                    <span style={{ flex: 1 }}>
                      <span style={{ fontSize: 14, fontWeight: 600, color: on ? "var(--accent-press)" : "var(--ink)", display: "block" }}>{o.label}</span>
                      <span style={{ fontSize: 12.5, color: "var(--muted)" }}>{o.desc}</span>
                    </span>
                    <span style={{ width: 20, height: 20, borderRadius: 999, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
                      border: "1.5px solid " + (on ? "var(--accent)" : "var(--border-strong)"), color: "#fff",
                      background: on ? "var(--accent)" : "transparent" }}>
                      {on && <Icon name="check" size={12} />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* nav */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <button className="btn btn-ghost" onClick={() => setIdx(Math.max(0, idx - 1))} disabled={idx === 0}
            style={{ opacity: idx === 0 ? .5 : 1 }}>
            <Icon name="chevR" size={14} style={{ transform: "rotate(180deg)" }} /> Previous
          </button>
          <span style={{ fontSize: 12.5, color: "var(--faint)" }}>{selected == null ? "Select an answer to continue" : "Answer saved automatically"}</span>
          <button className="btn btn-primary" onClick={next} style={{ opacity: selected == null ? .55 : 1 }}>
            {idx >= q.total - 1 ? "Finish & see results" : "Next question"} <Icon name="arrowR" size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Quiz });
