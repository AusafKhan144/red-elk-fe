/* Red Elk — Report screen */

/* Radar chart (polygon) */
function Radar({ dims, size = 300, color }) {
  const cx = size / 2, cy = size / 2, R = size / 2 - 38;
  const n = dims.length;
  const angle = (i) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const pt = (i, r) => [cx + Math.cos(angle(i)) * R * r, cy + Math.sin(angle(i)) * R * r];
  const [grow, setGrow] = useState(0);
  useEffect(() => { const t = setTimeout(() => setGrow(1), 100); return () => clearTimeout(t); }, []);
  const rings = [0.25, 0.5, 0.75, 1];
  const poly = dims.map((d, i) => pt(i, (d.score / 100) * grow).join(",")).join(" ");
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {rings.map((r, ri) => (
        <polygon key={ri}
          points={dims.map((_, i) => pt(i, r).join(",")).join(" ")}
          fill={ri === rings.length - 1 ? "var(--surface-2)" : "none"}
          stroke="var(--border)" strokeWidth="1" />
      ))}
      {dims.map((_, i) => {
        const [x, y] = pt(i, 1);
        return <line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke="var(--border)" strokeWidth="1" />;
      })}
      <polygon points={poly} fill={color} fillOpacity="0.14" stroke={color} strokeWidth="2"
        style={{ transition: "all 1s var(--ease)" }} />
      {dims.map((d, i) => {
        const [x, y] = pt(i, (d.score / 100) * grow);
        return <circle key={i} cx={x} cy={y} r="3.4" fill={color} style={{ transition: "all 1s var(--ease)" }} />;
      })}
      {dims.map((d, i) => {
        const [x, y] = pt(i, 1.17);
        const short = d.label.split(" ")[0];
        return <text key={i} x={x} y={y} textAnchor="middle" dominantBaseline="middle"
          style={{ fontSize: 10.5, fill: "var(--muted)", fontWeight: 600, fontFamily: "var(--font-ui)" }}>{short}</text>;
      })}
    </svg>
  );
}

/* the hero maturity matrix — each dimension a tier-banded track with a marker */
function MaturityTrack({ d, delay }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(d.score);
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(1), 100 + delay); return () => clearTimeout(t); }, []);
  return (
    <div style={{ padding: "15px 0", borderBottom: "1px solid var(--border)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 9 }}>
        <span style={{ fontSize: 13.5, fontWeight: 600 }}>{d.label}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <TierChip tier={tier.key} size="sm" />
          <span className="mono tnum" style={{ fontSize: 15, fontWeight: 600, width: 28, textAlign: "right" }}>{d.score}</span>
        </div>
      </div>
      <div style={{ position: "relative", height: 22 }}>
        {/* tier band background */}
        <div style={{ position: "absolute", inset: "6px 0", display: "flex", gap: 2, borderRadius: 6, overflow: "hidden" }}>
          {D.tiers.map((t) => (
            <div key={t.key} style={{ flex: (t.range[1] - t.range[0]),
              background: "color-mix(in srgb, " + t.color + " 13%, var(--surface))" }} />
          ))}
        </div>
        {/* marker */}
        <div style={{ position: "absolute", top: 0, bottom: 0, left: `calc(${d.score}% * ${w})`,
          transition: "left .9s var(--ease)", transform: "translateX(-50%)" }}>
          <div style={{ width: 4, height: "100%", borderRadius: 999, background: tier.color, boxShadow: "0 0 0 3px var(--surface)" }} />
        </div>
        {/* prev marker (hollow) */}
        <div style={{ position: "absolute", top: 4, bottom: 4, left: d.prev + "%", transform: "translateX(-50%)" }}
          title={"Previous: " + d.prev}>
          <div style={{ width: 2, height: "100%", background: "var(--faint)", opacity: .55, borderRadius: 999 }} />
        </div>
      </div>
    </div>
  );
}

function DimCard({ d }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(d.score);
  return (
    <div className="card" style={{ padding: 16, display: "flex", flexDirection: "column", gap: 9 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span className="mono tnum" style={{ fontSize: 22, fontWeight: 600, color: tier.color }}>{d.score}</span>
        <TierChip tier={tier.key} size="sm" />
      </div>
      <h4 style={{ fontSize: 13.5, fontWeight: 600 }}>{d.label}</h4>
      <p style={{ margin: 0, fontSize: 12.5, color: "var(--muted)", lineHeight: 1.5 }}>{d.note}</p>
    </div>
  );
}

function GlanceRow({ icon, tint, label, name, score, last }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0",
      borderBottom: last ? "none" : "1px solid var(--border)" }}>
      <span style={{ width: 32, height: 32, borderRadius: 9, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
        color: tint, background: "color-mix(in srgb, " + tint + " 12%, var(--surface))" }}><Icon name={icon} size={16} /></span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 11, color: "var(--faint)" }}>{label}</div>
        <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
      </div>
      <span className="mono tnum" style={{ fontSize: 14, fontWeight: 600, color: tint }}>{score}</span>
    </div>
  );
}

function Report({ go }) {
  const D = window.RE_DATA;
  const tier = D.tierOf(D.overall);
  const tierIdx = D.tiers.findIndex((t) => t.key === tier.key);
  const sorted = [...D.dimensions].sort((a, b) => b.score - a.score);
  const strongest = sorted[0], weakest = sorted[sorted.length - 1];
  const mover = [...D.dimensions].sort((a, b) => (b.score - b.prev) - (a.score - a.prev))[0];

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: 22 }}>

      {/* hero */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 24, alignItems: "center", padding: 24 }}>
          <ScoreDial score={D.overall} size={120} />
          <div>
            <span className="eyebrow">AI Maturity Report · Enterprise AI Maturity</span>
            <h1 className="display" style={{ fontSize: 30, margin: "8px 0 10px", lineHeight: 1.05 }}>
              Your organisation is <span style={{ color: tier.color }}>{tier.label}</span>
            </h1>
            <p style={{ margin: 0, fontSize: 14, color: "var(--muted)", maxWidth: 460, lineHeight: 1.55 }}>
              Scored {D.overall}/100 across six capability dimensions, benchmarked against 208 companies in your sector.
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <button className="btn btn-primary"><Icon name="download" size={14} /> Download PDF</button>
            <button className="btn btn-ghost" onClick={() => go("quiz")}><Icon name="play" size={13} fill /> Retake</button>
          </div>
        </div>
        {/* maturity journey */}
        <div style={{ display: "flex", borderTop: "1px solid var(--border)" }}>
          {D.tiers.map((t, i) => {
            const active = i === tierIdx, past = i < tierIdx;
            return (
              <div key={t.key} style={{ flex: 1, padding: "12px 16px", textAlign: "center",
                borderRight: i < 3 ? "1px solid var(--border)" : "none",
                background: active ? "color-mix(in srgb, " + t.color + " 9%, var(--surface))" : "var(--surface)",
                borderTop: active ? "2px solid " + t.color : "2px solid transparent" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                  {past && <span style={{ color: t.color, display: "flex" }}><Icon name="check" size={13} /></span>}
                  <span style={{ fontSize: 13, fontWeight: active ? 700 : 500, color: active ? "var(--ink)" : past ? "var(--muted)" : "var(--faint)" }}>{t.label}</span>
                </div>
                <div className="mono" style={{ fontSize: 10.5, marginTop: 3, color: active ? t.color : "var(--faint)" }}>{t.range[0]}–{t.range[1]}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* footprint: radar + at-a-glance */}
      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 18 }}>
        <div className="card" style={{ padding: 22 }}>
          <SectionHead title="Capability footprint" sub="Your maturity shape across all six dimensions." />
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: "6px 0" }}>
            <Radar dims={D.dimensions} size={296} color={tier.color} />
          </div>
        </div>

        <div className="card" style={{ padding: 22, display: "flex", flexDirection: "column" }}>
          <SectionHead title="At a glance" />
          <div style={{ display: "flex", flexDirection: "column" }}>
            <GlanceRow icon="trend" tint="var(--t-leading)" label="Strongest capability"
              name={strongest.label} score={strongest.score} />
            <GlanceRow icon="flag" tint="var(--accent)" label="Biggest opportunity"
              name={weakest.label} score={weakest.score} />
            <GlanceRow icon="arrowUp" tint="var(--t-maturing)" label="Most improved"
              name={mover.label} score={"+" + (mover.score - mover.prev)} />
            <GlanceRow icon="target" tint="var(--t-developing)" label="Sector benchmark"
              name="You vs. 208 peers" score="Top 18%" last />
          </div>
          <button className="btn btn-soft" style={{ marginTop: "auto", justifyContent: "center" }} onClick={() => go("benchmarks")}>
            <Icon name="target" size={14} /> Compare to peers
          </button>
        </div>
      </div>

      {/* matrix */}
      <div className="card" style={{ padding: 22 }}>
        <SectionHead title="Maturity by dimension"
          sub="Where each capability sits on the maturity scale. The faint line marks your previous score." />
        <div style={{ display: "flex", gap: 18, marginBottom: 4 }}>
          {D.tiers.map((t) => (
            <span key={t.key} style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11, color: "var(--muted)" }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: t.color }} />{t.label}
            </span>
          ))}
        </div>
        <div style={{ borderTop: "1px solid var(--border)" }}>
          {D.dimensions.map((d, i) => <MaturityTrack key={d.id} d={d} delay={i * 80} />)}
        </div>
      </div>

      {/* dimension recommendation cards */}
      <div>
        <SectionHead title="Insights & recommendations" sub="What's driving your score in each area." />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {D.dimensions.map((d) => <DimCard key={d.id} d={d} />)}
        </div>
      </div>

      {/* priority callout */}
      <div className="card" style={{ padding: 22, display: "flex", gap: 18, alignItems: "center",
        background: "color-mix(in srgb, var(--accent) 5%, var(--surface))", borderColor: "color-mix(in srgb, var(--accent) 22%, var(--border))" }}>
        <div style={{ width: 46, height: 46, borderRadius: 12, background: "var(--accent-soft)", color: "var(--accent)",
          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Icon name="flag" size={22} />
        </div>
        <div style={{ flex: 1 }}>
          <span className="eyebrow" style={{ color: "var(--accent)" }}>Top priority</span>
          <h3 style={{ fontSize: 16, fontWeight: 600, margin: "5px 0 4px" }}>Strengthen Governance &amp; Risk to unlock your next tier</h3>
          <p style={{ margin: 0, fontSize: 13, color: "var(--muted)", lineHeight: 1.5, maxWidth: 620 }}>
            At 58, governance is your lowest-scoring dimension and the main barrier to reaching <strong style={{ color: "var(--ink)" }}>Leading</strong>. Establish systematic model monitoring and a formal risk register.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => go("plan")}>View action plan <Icon name="arrowR" size={14} /></button>
      </div>
    </div>
  );
}

Object.assign(window, { Report, Radar, GlanceRow });
